document.addEventListener('DOMContentLoaded', function () {
    // Initialize Chart.js
    var ctx = document.getElementById('foodChart').getContext('2d');
    var foodChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: [],
            datasets: [{
                data: [],
                backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4CAF50', '#FF9800'],
            }]
        }
    });

    // Function to update the chart
    function updateChart() {
        foodChart.update();
    }

    // Function to calculate and update the totals
    function updateTotals() {
        var totalCalories = 0;
        var totalFat = 0;
        var totalProtein = 0;
        var totalCarbs = 0;

        // Loop through each entry in the chart data
        foodChart.data.labels.forEach(function (label, index) {
            totalCalories += parseFloat(foodChart.data.datasets[0].data[index]);
            totalFat += parseFloat(foodChart.data.datasets[0].data[index] * 0.3); // Assuming 30% of calories come from fat
            totalProtein += parseFloat(foodChart.data.datasets[0].data[index] * 0.15); // Assuming 15% of calories come from protein
            totalCarbs += parseFloat(foodChart.data.datasets[0].data[index] * 0.55); // Assuming 55% of calories come from carbohydrates
        });

        // Update the HTML elements
        document.getElementById('totalCalories').innerText = totalCalories.toFixed(2);
        document.getElementById('totalFat').innerText = totalFat.toFixed(2);
        document.getElementById('totalProtein').innerText = totalProtein.toFixed(2);
        document.getElementById('totalCarbs').innerText = totalCarbs.toFixed(2);
    }

    // Function to handle form submission
    window.submitForm = function () {
        var foodName = document.getElementById('foodName').value;
        var servingSize = parseFloat(document.getElementById('servingSize').value);

        // Validate input
        if (!foodName || isNaN(servingSize) || servingSize <= 0) {
            alert('Please enter valid values for food name and serving size.');
            return;
        }

        // Add the new entry to the chart
        foodChart.data.labels.push(foodName);
        foodChart.data.datasets[0].data.push(servingSize);

        // Update the chart and totals
        updateChart();
        updateTotals();

        // Clear the form
        document.getElementById('foodName').value = '';
        document.getElementById('servingSize').value = '';
    };
});
